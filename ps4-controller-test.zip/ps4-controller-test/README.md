# PS4 Controller Test (homebrew)

Teste de controle para PS4 feito com o toolchain **OpenOrbis**. GUI mínima (retângulos + fonte 5x7 embutida, sem imagens nem assets).

## Controles

- **Segure L1 + L2** e aperte **R1** = próximo teste / **R2** = teste anterior (dá a volta).

## Testes

1. Botões (setas, △ ○ ✕ □, L1, R1, L2, R2, Options, clique do touchpad) + barras analógicas de L2/R2
2. Touchpad: cursor em cruz para até 2 dedos (azul e rosa) + coordenadas + clique
3. Analógicos: posição (0–255) dos dois sticks; a caixa fica verde ao apertar L3/R3
4. Barra de luz: ciclo de cores RGB (volta para azul ao sair do teste)
5. Sensores: acelerômetro, giroscópio e quaternion de orientação, em barras centradas
6. Vibração: segure **L1** = motor esquerdo, **R1** = motor direito; **L1+R1** ou **clique do touchpad** = os dois

## Como compilar

Com o OpenOrbis instalado (Linux) e `clang` + `lld` (+ dotnet para o PkgTool):

```
export OO_PS4_TOOLCHAIN=/caminho/do/sdk
make        # gera build/eboot.bin
make pkg    # gera o PKG em build/pkg/
```

O `make pkg` cria tudo sozinho: `param.sfo` (via `PkgTool.Core sfo_setentry`), `pkg.gp4` (via `create-gp4`) e o `.pkg`. Título, Title ID e Content ID ficam no topo do `Makefile`.

**Ícone:** coloque um `icon.png` 512x512 na pasta do projeto (`make pkg` copia para `sce_sys/icon0.png`). Sem ele, um ícone placeholder é gerado.

Também há um workflow do GitHub Actions (`.github/workflows/build.yml`, fora deste ZIP) que faz tudo isso automaticamente, usando o `icon.png` da raiz do repo.

## Avisos importantes

- **Não foi compilado com o toolchain real nem testado em um PS4.** O Makefile também foi escrito de memória a partir do template do toolchain. Os nomes de funções, structs e constantes (`sceVideoOut*`, `scePad*`, `ORBIS_PAD_BUTTON_*`, `OrbisPadData`...) foram escritos de memória. Se o compilador reclamar de algum nome, compare com os samples e headers do seu toolchain (`orbis/VideoOut.h`, `orbis/Pad.h`). A parte de vídeo (`video_init`) é a mais provável de precisar de ajuste; compare com o sample gráfico.
- Os botões **PS** e **Share** são reservados pelo sistema e não chegam ao app, então não dá pra testá-los.
- As escalas das barras do teste de sensores (`ACC_RANGE`, `GYRO_RANGE`, `QUAT_RANGE`, no topo do `main.c`) são chutes; ajuste conforme o que você ver na tela.
- Requer console com jailbreak/homebrew habilitado.
