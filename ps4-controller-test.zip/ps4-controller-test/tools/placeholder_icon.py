#!/usr/bin/env python3
"""Gera um icone 512x512 (PNG) simples, usado quando nao ha icon.png."""
import struct, sys, zlib

W = H = 512
out = sys.argv[1] if len(sys.argv) > 1 else "icon0.png"

def chunk(tag, data):
    body = tag + data
    return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

rows = []
for y in range(H):
    row = bytearray([0])  # filtro 0
    for x in range(W):
        if x < 24 or y < 24 or x >= W - 24 or y >= H - 24:
            px = (46, 204, 113)
        elif 160 <= x < 352 and 160 <= y < 352:
            px = (230, 230, 230)
        else:
            px = (16, 20, 24)
        row += bytes(px)
    rows.append(bytes(row))

png = (b"\x89PNG\r\n\x1a\n"
       + chunk(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 2, 0, 0, 0))
       + chunk(b"IDAT", zlib.compress(b"".join(rows), 9))
       + chunk(b"IEND", b""))
open(out, "wb").write(png)
