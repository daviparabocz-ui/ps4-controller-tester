/*
 * PS4 Controller Test - homebrew (OpenOrbis), GUI minima em software.
 *
 * Trocar de teste: SEGURE L1 + L2, e aperte R1 (proximo) ou R2 (anterior).
 * Testes: 1 botoes | 2 touchpad | 3 analogicos (+L3/R3) | 4 barra de luz | 5 sensores
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <orbis/libkernel.h>
#include <orbis/VideoOut.h>
#include <orbis/Pad.h>
#include <orbis/UserService.h>
#include "font5x7.h"

/* ---------- Layout proprio do ScePadData (evita depender dos nomes dos campos do header) ---------- */
typedef struct { uint8_t x, y; } PadStick;
typedef struct { uint8_t l2, r2, pad[2]; } PadAnalogBtn;
typedef struct { float x, y, z, w; } PadQuat;
typedef struct { float x, y, z; } PadVec3;
typedef struct { uint16_t x, y; uint8_t id; uint8_t rsv[3]; } PadTouch;
typedef struct { uint8_t touchNum; uint8_t rsv[3]; uint32_t rsv1; PadTouch touch[2]; } PadTouchData;
typedef struct {
    uint32_t buttons;
    PadStick leftStick, rightStick;
    PadAnalogBtn analogButtons;
    PadQuat orientation;
    PadVec3 acceleration;
    PadVec3 angularVelocity;
    PadTouchData touchData;
    uint8_t connected;
    uint8_t rsv0[3];
    uint64_t timestamp;
    uint8_t tail[256]; /* folga: o sistema escreve o struct completo (extensao, etc.) */
} PadData;

_Static_assert(offsetof(PadData, orientation) == 12, "layout pad");
_Static_assert(offsetof(PadData, acceleration) == 28, "layout pad");
_Static_assert(offsetof(PadData, angularVelocity) == 40, "layout pad");
_Static_assert(offsetof(PadData, touchData) == 52, "layout pad");

typedef struct { uint8_t r, g, b, a; } LightColor;

/* ---------- Config ---------- */
#define W 1920
#define H 1080
#define NBUF 2
#define FB_SIZE 0x800000 /* 1920*1080*4 arredondado para multiplo de 2MB */

/* Escala das barras do teste de sensores (ajuste se achar pequeno/grande) */
#define ACC_RANGE 10.0f
#define GYRO_RANGE 10.0f
#define QUAT_RANGE 1.0f

#define NUM_TESTS 5

/* ---------- Cores (0xAARRGGBB) ---------- */
#define C_BG 0xFF101418
#define C_BAR 0xFF1E2630
#define C_TEXT 0xFFE6E6E6
#define C_DIM 0xFF6B7684
#define C_ON 0xFF2ECC71
#define C_OFF 0xFF2A323D
#define C_ACC 0xFF3498DB
#define C_ALT 0xFFE67E22
#define C_PINK 0xFFE84393

/* ---------- Video ---------- */
static int videoHandle;
static OrbisKernelEqueue flipQueue;
static uint32_t *fb[NBUF];
static uint32_t *cur; /* buffer onde estamos desenhando */

static int video_init(void) {
    int r;
    videoHandle = sceVideoOutOpen(ORBIS_VIDEO_USER_MAIN, 0 /* bus MAIN */, 0, NULL);
    if (videoHandle < 0) return videoHandle;

    r = sceKernelCreateEqueue(&flipQueue, "flip_queue");
    if (r < 0) return r;
    sceVideoOutAddFlipEvent(flipQueue, videoHandle, NULL);

    off_t phys = 0;
    size_t total = (size_t)FB_SIZE * NBUF;
    r = sceKernelAllocateDirectMemory(0, sceKernelGetDirectMemorySize(), total, 0x200000, 3, &phys);
    if (r < 0) return r;

    void *base = NULL;
    r = sceKernelMapDirectMemory(&base, total, 0x33, 0, phys, 0x200000);
    if (r < 0) return r;

    void *addrs[NBUF];
    for (int i = 0; i < NBUF; i++) {
        fb[i] = (uint32_t *)((uint8_t *)base + (size_t)i * FB_SIZE);
        addrs[i] = fb[i];
    }

    OrbisVideoOutBufferAttribute attr;
    sceVideoOutSetBufferAttribute(&attr,
                                  0x80000000 /* A8R8G8B8_SRGB (B,G,R,A em memoria) */,
                                  ORBIS_VIDEO_OUT_TILING_MODE_LINEAR,
                                  ORBIS_VIDEO_OUT_ASPECT_RATIO_16_9,
                                  W, H, W);
    r = sceVideoOutRegisterBuffers(videoHandle, 0, addrs, NBUF, &attr);
    if (r < 0) return r;
    sceVideoOutSetFlipRate(videoHandle, 0);
    return 0;
}

static void present(int idx) {
    sceVideoOutSubmitFlip(videoHandle, idx, ORBIS_VIDEO_OUT_FLIP_VSYNC, 0);
    OrbisKernelEvent ev;
    int n;
    sceKernelWaitEqueue(flipQueue, &ev, 1, &n, NULL);
}

/* ---------- Desenho ---------- */
static void rect(int x, int y, int w, int h, uint32_t c) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > W) w = W - x;
    if (y + h > H) h = H - y;
    for (int j = 0; j < h; j++) {
        uint32_t *row = cur + (size_t)(y + j) * W + x;
        for (int i = 0; i < w; i++) row[i] = c;
    }
}

static void frame(int x, int y, int w, int h, int t, uint32_t c) {
    rect(x, y, w, t, c);
    rect(x, y + h - t, w, t, c);
    rect(x, y, t, h, c);
    rect(x + w - t, y, t, h, c);
}

static void draw_char(int x, int y, char ch, int s, uint32_t c) {
    if (ch >= 'a' && ch <= 'z') ch -= 32;
    if (ch < 32 || ch > 90) ch = '?';
    const uint8_t *g = font5x7[ch - 32];
    for (int col = 0; col < 5; col++)
        for (int row = 0; row < 7; row++)
            if (g[col] & (1 << row)) rect(x + col * s, y + row * s, s, s, c);
}

static void text(int x, int y, const char *str, int s, uint32_t c) {
    for (; *str; str++, x += 6 * s) draw_char(x, y, *str, s, c);
}

static int text_w(const char *str, int s) { return (int)strlen(str) * 6 * s; }

static void fmt2(char *out, size_t n, float f) {
    int v = (int)(f * 100.0f + (f >= 0 ? 0.5f : -0.5f));
    int neg = v < 0;
    if (neg) v = -v;
    snprintf(out, n, "%s%d.%02d", neg ? "-" : "", v / 100, v % 100);
}

static void bar(int x, int y, int w, int h, int v, int vmax, uint32_t c) {
    rect(x, y, w, h, C_OFF);
    rect(x, y, w * v / vmax, h, c);
    frame(x, y, w, h, 2, C_DIM);
}

static void bar_centered(int x, int y, int w, int h, float v, float range, uint32_t c) {
    if (v > range) v = range;
    if (v < -range) v = -range;
    int half = w / 2;
    int len = (int)(v / range * half);
    rect(x, y, w, h, C_OFF);
    if (len >= 0) rect(x + half, y + 2, len, h - 4, c);
    else rect(x + half + len, y + 2, -len, h - 4, c);
    rect(x + half - 1, y, 2, h, C_TEXT);
    frame(x, y, w, h, 2, C_DIM);
}

static void hsv_to_rgb(int hue, uint8_t *r, uint8_t *g, uint8_t *b) {
    int region = (hue % 360) / 60;
    int f = ((hue % 360) % 60) * 255 / 60;
    int q = 255 - f;
    switch (region) {
        case 0: *r = 255; *g = f; *b = 0; break;
        case 1: *r = q; *g = 255; *b = 0; break;
        case 2: *r = 0; *g = 255; *b = f; break;
        case 3: *r = 0; *g = q; *b = 255; break;
        case 4: *r = f; *g = 0; *b = 255; break;
        default: *r = 255; *g = 0; *b = q; break;
    }
}

/* ---------- Testes ---------- */
static const char *TITLES[NUM_TESTS] = {
    "TESTE DOS BOTOES", "TESTE DO TOUCHPAD", "TESTE DOS ANALOGICOS",
    "TESTE DA BARRA DE LUZ", "TESTE DOS SENSORES"};

typedef struct { uint32_t mask; const char *label; } BtnDef;
static const BtnDef BTNS[] = {
    {ORBIS_PAD_BUTTON_UP, "CIMA"},     {ORBIS_PAD_BUTTON_DOWN, "BAIXO"},
    {ORBIS_PAD_BUTTON_LEFT, "ESQ"},    {ORBIS_PAD_BUTTON_RIGHT, "DIR"},
    {ORBIS_PAD_BUTTON_TRIANGLE, "TRIANGULO"}, {ORBIS_PAD_BUTTON_CIRCLE, "BOLA"},
    {ORBIS_PAD_BUTTON_CROSS, "X"},     {ORBIS_PAD_BUTTON_SQUARE, "QUADRADO"},
    {ORBIS_PAD_BUTTON_L1, "L1"},       {ORBIS_PAD_BUTTON_R1, "R1"},
    {ORBIS_PAD_BUTTON_L2, "L2"},       {ORBIS_PAD_BUTTON_R2, "R2"},
    {ORBIS_PAD_BUTTON_OPTIONS, "OPTIONS"}, {ORBIS_PAD_BUTTON_TOUCH_PAD, "TOUCHPAD"},
};
#define NBTNS ((int)(sizeof(BTNS) / sizeof(BTNS[0])))

static void test_buttons(const PadData *d) {
    const int cw = 380, ch = 110, gap = 20, x0 = 170, y0 = 170;
    for (int i = 0; i < NBTNS; i++) {
        int x = x0 + (i % 4) * (cw + gap);
        int y = y0 + (i / 4) * (ch + gap);
        int on = (d->buttons & BTNS[i].mask) != 0;
        rect(x, y, cw, ch, on ? C_ON : C_OFF);
        frame(x, y, cw, ch, 3, on ? C_TEXT : C_DIM);
        int tw = text_w(BTNS[i].label, 4);
        text(x + (cw - tw) / 2, y + (ch - 28) / 2, BTNS[i].label, 4, C_TEXT);
    }
    char buf[32];
    text(x0, 720, "L2", 3, C_TEXT);
    bar(x0 + 80, 715, 600, 36, d->analogButtons.l2, 255, C_ACC);
    snprintf(buf, sizeof buf, "%d", d->analogButtons.l2);
    text(x0 + 700, 722, buf, 3, C_TEXT);

    text(x0 + 820, 720, "R2", 3, C_TEXT);
    bar(x0 + 900, 715, 600, 36, d->analogButtons.r2, 255, C_ACC);
    snprintf(buf, sizeof buf, "%d", d->analogButtons.r2);
    text(x0 + 1520, 722, buf, 3, C_TEXT);
}

static void test_touchpad(const PadData *d) {
    const int x0 = 160, y0 = 170, w = 1600, h = 785; /* proporcao ~1920x942 */
    int click = (d->buttons & ORBIS_PAD_BUTTON_TOUCH_PAD) != 0;
    rect(x0, y0, w, h, click ? 0xFF1E4D2F : C_OFF);
    frame(x0, y0, w, h, 4, click ? C_ON : C_DIM);
    text(x0 + 20, y0 + 16, click ? "CLIQUE!" : "TOQUE NO TOUCHPAD", 3, C_DIM);

    int n = d->touchData.touchNum;
    if (n > 2) n = 2;
    for (int i = 0; i < n; i++) {
        int px = x0 + d->touchData.touch[i].x * w / 1920;
        int py = y0 + d->touchData.touch[i].y * h / 942;
        uint32_t c = i == 0 ? C_ACC : C_PINK;
        rect(px - 40, py - 2, 80, 4, c); /* cursor em cruz */
        rect(px - 2, py - 40, 4, 80, c);
        rect(px - 10, py - 10, 20, 20, c);
        char buf[48];
        snprintf(buf, sizeof buf, "%d: %d,%d", i + 1, d->touchData.touch[i].x, d->touchData.touch[i].y);
        text(x0 + 20 + i * 400, y0 + h - 40, buf, 3, c);
    }
}

static void stick_box(int cx, int cy, int size, uint8_t sx, uint8_t sy, int pressed, const char *name) {
    int x = cx - size / 2, y = cy - size / 2;
    rect(x, y, size, size, pressed ? 0xFF1E4D2F : C_OFF);
    frame(x, y, size, size, 4, pressed ? C_ON : C_DIM);
    rect(cx - 1, y, 2, size, C_DIM);
    rect(x, cy - 1, size, 2, C_DIM);
    int px = x + sx * size / 255;
    int py = y + sy * size / 255;
    rect(px - 14, py - 14, 28, 28, pressed ? C_ON : C_ACC);
    char buf[48];
    snprintf(buf, sizeof buf, "X:%d Y:%d", sx, sy);
    text(cx - text_w(buf, 3) / 2, y + size + 20, buf, 3, C_TEXT);
    text(cx - text_w(name, 3) / 2, y - 40, name, 3, pressed ? C_ON : C_TEXT);
}

static void test_sticks(const PadData *d) {
    stick_box(520, 560, 480, d->leftStick.x, d->leftStick.y,
              (d->buttons & ORBIS_PAD_BUTTON_L3) != 0, "ANALOGICO ESQ (L3)");
    stick_box(1400, 560, 480, d->rightStick.x, d->rightStick.y,
              (d->buttons & ORBIS_PAD_BUTTON_R3) != 0, "ANALOGICO DIR (R3)");
}

static void test_lightbar(PadData *d, int pad, unsigned frameNo) {
    (void)d;
    uint8_t r, g, b;
    hsv_to_rgb((int)((frameNo * 2) % 360), &r, &g, &b);
    LightColor lb = {r, g, b, 0};
    scePadSetLightBar(pad, (OrbisPadColor *)&lb);

    rect(560, 220, 800, 480, 0xFF000000 | ((uint32_t)r << 16) | ((uint32_t)g << 8) | b);
    frame(560, 220, 800, 480, 4, C_DIM);
    char buf[48];
    snprintf(buf, sizeof buf, "R:%d G:%d B:%d", r, g, b);
    text(960 - text_w(buf, 4) / 2, 740, buf, 4, C_TEXT);
}

static void sensor_row(int y, const char *label, float v, float range, uint32_t c) {
    char buf[24];
    text(170, y, label, 3, C_TEXT);
    fmt2(buf, sizeof buf, v);
    text(420, y, buf, 3, C_TEXT);
    bar_centered(720, y - 8, 1000, 40, v, range, c);
}

static void test_sensors(const PadData *d) {
    int y = 180;
    const int step = 62;
    sensor_row(y, "ACC X", d->acceleration.x, ACC_RANGE, C_ACC); y += step;
    sensor_row(y, "ACC Y", d->acceleration.y, ACC_RANGE, C_ACC); y += step;
    sensor_row(y, "ACC Z", d->acceleration.z, ACC_RANGE, C_ACC); y += step + 20;
    sensor_row(y, "GIRO X", d->angularVelocity.x, GYRO_RANGE, C_ALT); y += step;
    sensor_row(y, "GIRO Y", d->angularVelocity.y, GYRO_RANGE, C_ALT); y += step;
    sensor_row(y, "GIRO Z", d->angularVelocity.z, GYRO_RANGE, C_ALT); y += step + 20;
    sensor_row(y, "QUAT X", d->orientation.x, QUAT_RANGE, C_PINK); y += step;
    sensor_row(y, "QUAT Y", d->orientation.y, QUAT_RANGE, C_PINK); y += step;
    sensor_row(y, "QUAT Z", d->orientation.z, QUAT_RANGE, C_PINK); y += step;
    sensor_row(y, "QUAT W", d->orientation.w, QUAT_RANGE, C_PINK);
}

/* ---------- Main ---------- */
int main(void) {
    if (video_init() < 0) return -1;

    struct { int32_t priority; } up = {700}; /* FIFO_LOWEST */
    sceUserServiceInitialize((void *)&up);

    int userId = 0;
    sceUserServiceGetInitialUser(&userId);
    scePadInit();
    int pad = scePadOpen(userId, 0 /* standard */, 0, NULL);

    int test = 0, bufIdx = 0;
    uint32_t prev = 0;
    unsigned frameNo = 0;

    for (;;) {
        PadData d;
        memset(&d, 0, sizeof d);
        int rr = scePadReadState(pad, (OrbisPadData *)&d);

        /* Combo de troca: segurando L1+L2, R1 = proximo, R2 = anterior */
        uint32_t pressed = d.buttons & ~prev;
        int combo = (d.buttons & ORBIS_PAD_BUTTON_L1) && (d.buttons & ORBIS_PAD_BUTTON_L2);
        if (combo && (pressed & ORBIS_PAD_BUTTON_R1)) {
            test = (test + 1) % NUM_TESTS;
        } else if (combo && (pressed & ORBIS_PAD_BUTTON_R2)) {
            test = (test + NUM_TESTS - 1) % NUM_TESTS;
        }
        if ((combo && (pressed & (ORBIS_PAD_BUTTON_R1 | ORBIS_PAD_BUTTON_R2))) && test != 3) {
            LightColor def = {0, 0, 255, 0}; /* restaura azul ao sair da barra de luz */
            scePadSetLightBar(pad, (OrbisPadColor *)&def);
        }
        prev = d.buttons;

        cur = fb[bufIdx];
        rect(0, 0, W, H, C_BG);

        /* Cabecalho */
        rect(0, 0, W, 110, C_BAR);
        char title[64];
        snprintf(title, sizeof title, "[%d/%d] %s", test + 1, NUM_TESTS, TITLES[test]);
        text(120, 38, title, 5, C_TEXT);

        if (rr < 0) {
            text(120, 500, "SEM LEITURA DO CONTROLE", 5, C_ALT);
        } else {
            switch (test) {
                case 0: test_buttons(&d); break;
                case 1: test_touchpad(&d); break;
                case 2: test_sticks(&d); break;
                case 3: test_lightbar(&d, pad, frameNo); break;
                case 4: test_sensors(&d); break;
            }
        }

        /* Rodape */
        rect(0, H - 80, W, 80, C_BAR);
        text(120, H - 56, "SEGURE L1+L2:  R1 PROXIMO  /  R2 ANTERIOR", 3, C_DIM);

        present(bufIdx);
        bufIdx = (bufIdx + 1) % NBUF;
        frameNo++;
    }
    return 0;
}
